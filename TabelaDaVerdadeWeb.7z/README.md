"# TabelaDaVerdade" 
